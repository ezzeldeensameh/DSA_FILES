clear
clc

%----------------------- Configuration ------------------------------------

pay_len = 32;       % Payload length in number of symbols
sf = 7;             % Spreading factor
n_frame = 0;        % Number of frames (not used if random payload selected)                    

%------------------- Read measurements files ------------------------------

% reference payload
ref_symb1 = fread(fopen('measurements/mu_source_s1.txt'),'short');
ref_symb2 = fread(fopen('measurements/mu_source_s2.txt'),'short'); 

ref_symb1 = reshape(ref_symb1,pay_len,length(ref_symb1)/pay_len);
ref_symb2 = reshape(ref_symb2,pay_len,length(ref_symb2)/pay_len);
n_frame = length(ref_symb1);


% Log of the synchronisation block state containing interleaved value of
% detection offset and detection case.
% Possible cases:  0: Power1 < Power2 
%                  1: Power1 > Power2
%                  2: Only one user detected

sync_info = fread(fopen('measurements/sync_state.txt'),'int');

detect_interval = diff(sync_info(1:2:end));
detect_state = sync_info(2:2:end).';

% Demodulated symbols
symb1 = fread(fopen('measurements/mu_demod_s1.txt'),'short');
symb2 = fread(fopen('measurements/mu_demod_s2.txt'),'short');

symb1 = symb1(1:floor(length(symb1)/32)*32);
symb2 = symb2(1:floor(length(symb2)/32)*32);

symb1 = reshape(symb1,pay_len,length(symb1)/pay_len);
symb2 = reshape(symb2,pay_len,length(symb2)/pay_len);

%----------------------- initialisation -----------------------------------
err1 = []; % errors of user 1
err2 = []; % errors of user 2

symb_cnt=[1,1,1,1]; %counter for reference_symb, received_S1, received_S2, detect_state , valid_frame

ID_log = zeros(1,2); % log frame ID considered as valid and invalid
frame_id = -1; % all initial frame ID value is accepted (as ID > -1)

for i = 1:length(detect_state)
    if detect_state(symb_cnt(3)) == 0 % correct detection
        
        %check if the frame ID is two time the same (ID consists of two symbols)
        if 2^sf*symb1(1,symb_cnt(1)) + symb1(2,symb_cnt(1)) == 2^sf*symb1(3,symb_cnt(1)) + symb1(4,symb_cnt(1))
            % divide ID by three to get the frame reference position in
            % mu_source
            new_frame_id = (2^sf*symb1(1,symb_cnt(1)) + symb1(2,symb_cnt(1)))/3;
            
            %check if ID is integer
            if (new_frame_id~= floor(new_frame_id))
                ID_log(1,2) = ID_log(1,2) + 1;
                symb_cnt = symb_cnt+[1,1,1,0];
                
             %check if ID < n_frame
            elseif(new_frame_id >= n_frame)
                ID_log(1,2) = ID_log(1,2) + 1;
                symb_cnt = symb_cnt+[1,1,1,0];
            %check if new id greater than the previous one
            elseif(new_frame_id<=frame_id)   

                if (new_frame_id == frame_id)% If id already found, we shouldn't consider previous frame as well
                    symb_cnt = symb_cnt+[0,0,0,-1];
                end
                ID_log(1,2) = ID_log(1,2) + 1;
                symb_cnt = symb_cnt+[1,1,1,0];
            % Check if id has jump from more than 100
            elseif(new_frame_id-frame_id>100)

                ID_log(1,2) = ID_log(1,2) + 1;
                symb_cnt = symb_cnt+[1,1,1,0];
                
            % Check for a valid symbol in begining of frame, confirming ID validity
            elseif(sum(symb1(5,symb_cnt(1))~=ref_symb1(5,new_frame_id(end)+1)))
              
                ID_log(1,2) = ID_log(1,2) + 1;
                symb_cnt = symb_cnt+[1,1,1,0];
                
            % Check if the first symbol of user 2 corresponds to the ID  
            elseif symb1(1,symb_cnt(1))~= symb2(1,symb_cnt(2))
                    ID_log(1,2) = ID_log(1,2) + 1;
                    symb_cnt = symb_cnt+[1,1,1,0];   
            else % Frame Id valid, we can recover the errors
                ID_log(1,1) = ID_log(1,1) + 1;

                frame_id = new_frame_id;
                
                err1(:,symb_cnt(4)) = symb1(:,symb_cnt(1))-ref_symb1(:,frame_id+1);
                err2(:,symb_cnt(4)) = symb2(:,symb_cnt(2))-ref_symb2(:,frame_id+1);    
            
                symb_cnt = symb_cnt+[1,1,1,1];
            end
            
        
        else% ID not received two time
            symb_cnt = symb_cnt+[1,1,1,0];
        end
    
    elseif detect_state(symb_cnt(3)) == 1 % detect two user but wrong power order (P1>P2)
        symb_cnt = symb_cnt+[1,1,1,0];
    elseif detect_state(symb_cnt(3)) == 2 % detected only one user
        symb_cnt = symb_cnt+[1,0,1,0];
    end
        
end
%the errors of interest are the ones that occurs for symbols that are
%overlapping bettween the two users (and also not used for ID verifications)
err1 = err1(end-14:end,:);
err2 = err2(1:15,:);

% ----------------------------- plot result ------------------------------

figure()
sgtitle('Difference between reference and demodulated symbols')
subplot(2,1,1)
stem(err1(:))
xlabel('Symbols S1')
ylabel('Errors S1')

subplot(2,1,2)
stem(err2(:))
xlabel('Symbols S2')
ylabel('Errors S2')

% snr estimation
snr_lin = fread(fopen('measurements/mu_snr.txt'),'float');
snr_log = 10*log10(snr_lin);
snr_log = reshape(snr_log,8,length(snr_log)/8);
disp("SNR mean estimated for U1: "+mean(mean(snr_log))+" dB")
% figure
% plot(mean(snr_log)),hold on,grid on

disp("Symbols errors User 1: " + sum(err1(:)~=0))
disp("Symbols errors User 2: " + sum(err2(:)~=0))