#!/bin/bash
export PYTHONPATH=$PYTHONPATH:~/lora_sdr/lib64/python2.7/site-packages
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:~/lora_sdr/lib64/
